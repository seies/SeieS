#! /bin/bash
# Author: samli@tencent.com
# 2013-02-01

## ----------------------------------------------------------

. "$( dirname $0 )/cbl.sh" || exit 1
. "$( dirname $0 )/mtbash.sh"     || exit 1

cd "$WORKDIR" || exit 1

logd="$WORKDIR/log.d"
[[ -d $logd ]] || mkdir -p $logd

abs_iplist="$WORKDIR/abs-iplist"
abs_config="$WORKDIR/abs-config"

log_prefix="$logd/log_$( date +%Y%m%d_%H%M%S )_$RANDOM"
logfile_all="$logd/log.all"

touch "$logfile_all"

abs_max_job=50
ARG=$@

## supposed to echo in main.sh

okflag="OPOK"
notoklist="./notoklist"

#user=$(id | perl -lne ' print $1 if /^uid=\d+\((\w+)\) /'  )

run_abs()
{
    local line="$@"

    local iplist ip log

    case "$line" in 
    [1-9]*)

        iplist=$( mktemp -f "$WORKDIR/tmp_iplist.d" )
        ip=$( echo "$line" | awk '{ print $1 }' )
        user=$( echo "$line" | awk '{ print $2 }' )
        runmode=$( echo "$line" | awk '{ print $5 }' )
        log="${log_prefix}_$ip"

        #msg "running  [$ip]"
        echo "$line" > "$iplist"

        touch "$logfile_all"
		
	
	if [ $runmode = "key" ];then
		key_path=$( echo "$line" | awk '{ print $3 }' )
		chmod 400 $key_path
        bash ./abs.sh -i -y -N -t 60 -T 60 -L 999999 -l "$iplist" -c "$abs_config" \
         -u $user $ARG > $log 2>&1
	else
		bash ./abs.sh -y -N -t 60 -T 60 -L 999999 -l "$iplist" -c "$abs_config" \
		-u $user $ARG > $log 2>&1
	fi

        dos2unix "$log" &> /dev/null
        
        /bin/rm "$iplist"

        cat "$log" >> "$logfile_all"
        #msg "finished [$ip]"
	if grep -q 'install_failed' "$log";then
		msg "${ip}_install_failed"
	elif grep -q 'check_os_failed' "$log";then
		msg "${ip}_check_os_failed"
	elif grep -q 'check_runmode_failed' "$log";then
		msg "${ip}_check_runmode_failed"
	elif grep -q 'install_success' "$log";then
		msg "${ip}_install_success"
	elif grep -q 'modify_conf_failed' "$log";then
		msg "${ip}_modify_conf_failed"
	elif grep -q 'check_user_failed' "$log";then
		msg "${ip}_check_user_failed"
	elif grep -q 'copy_failed' "$log";then
		msg "${ip}_copy_failed"
	elif grep -q 'tar_xf_failed' "$log";then
		msg "${ip}_tar_xf_failed"
	elif grep -q 'telnet_server_port_failed' "$log";then
		msg "${ip}_telnet_server_port_failed"
	elif grep -q 'logon TIMEOUT' "$log";then
		msg "${ip}_logon_timeout"
	elif grep -q 'check_runmode_failed' "$log";then
		msg "${ip}_check_runmode_failed"
	elif grep -q 'copy_template_failed' "$log";then
		msg "${ip}_copy_template_failed"
	elif grep -q 'exe_file_not_exists' "$log";then
		msg "${ip}_exe_file_not_exists"
	elif grep -q 'Connection Refused' "$log";then
		msg "${ip}_connection_refused"
	elif grep -q 'Illegal host key' "$log";then
		msg "${ip}_illegal_host_key"
	elif grep -q 'Authentication failed' "$log";then
		msg "${ip}_authentication_failed"
	elif grep -q 'SCP FAILURE' "$log";then
		msg "${ip}_no_such_file"
	elif grep -q 'PASSWORD ERROR' "$log";then
		msg "${ip}_password_error"
	elif grep -q 'No route to host' "$log";then
		msg "${ip}_no_route_to_host"
	fi
        ;;
    *)
        return 
        ;;
    esac        
} 


## > "$notok_iplist"

#msg "----------------------------------------------------------------"
#rmsg "logdir [$logd]"
#rmsg  "logfile all: [$logfile_all]"
#msg "----------------------------------------------------------------"

mt_init "$abs_max_job"

while read; do
    mt_run run_abs "$REPLY" 
done < "$abs_iplist"

wait

## find "$logd" -name "$( basename ${log_prefix} )_*" | xargs cat > $logfile_all
## update timestamp
sleep 1

#msg "----------------------------------------------------------------"
#msg "LOGFILE: $logfile_all"
#msg "LOGFILE: log.d/$( basename $logfile_all )"

exit 



