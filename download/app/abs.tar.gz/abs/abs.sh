#!/bin/bash
####################################
# 2006.06 by echoqin
# Copyright (C) 2006 by tencent
#
# 2006.06 by echoqin
# 	added: key parameter check
#	added: configuration check
#	updated: force parameter check
#
# 2006.11 by echoqin
#	added: column id as parameter
#
# 2007.2.12 by echoqin
#	added: retry for passwd wrong, and passwd input no echo
#	added: prompt function
#	added: -y|--yes option
#	added: file or directory name wrong type in scp
#	modified: all output in chinese
#	added: support all passwd and sshport to be input
#
# 2008.8.27 by echoqin
#	modified: when passwd and ssh port must be input, extended columns back in the iplist gotten wrong, correct it
#	modified: extended columns in the iplist can be 1 to 6 most 
#
# 2012.11.30 by chapmanou
#	added: tlinux supported
#
# 2013.01.30 by echoqin
#	added: -r|--retry option
#
####################################

##########################################    proc defination    ##########################################
# 忽略规则设定
os_check()
{
	if [ -f /etc/tlinux-release ]; then
		OS_VER="tlinux"
	elif [ -f /etc/debian_version ];then
		OS_VER="ubuntu"
	else
		# Do NOT care
		OS_VER=""
	fi
}

ignore_init()
{
	arry_ignore_pwd_length=0
	if [ -s ./ignore_pwd ]; then
		while read IGNORE_PWD
		do
			arry_ignore_pwd[$arry_ignore_pwd_length]=$IGNORE_PWD	
			let arry_ignore_pwd_length=$arry_ignore_pwd_length+1
		done < ./ignore_pwd
	fi
	
	arry_ignore_ip_length=0
	if [ -s ./ignore_ip ]; then
		while read IGNORE_IP
		do
			arry_ignore_ip[$arry_ignore_ip_length]=$IGNORE_IP
			let arry_ignore_ip_length=$arry_ignore_ip_length+1
		done < ./ignore_ip
	fi
}

show_version()
{
	echo "abs version: 3.0.2(no_retry)"
	echo "update date: 2013.01.30"
	echo "author: echoqin"
}

show_usage()
{
	show_version
	echo ""
	echo "USAGE:$0"
	echo "	[-h|--help]			显示本帮助"
	echo "	[-v|-V|--version]		显示版本号"
	echo "	[-l|--iplist ... ]		自定义需要批量处理的机器列表，默认为abs-iplist"
	echo "					默认格式为：IP、密码、端口，之后还可附加其他信息"
	echo "					使用-p|--passwd参数时，格式为：IP，之后还可附加其他信息"
	echo "					登陆用户均已内置为root"
	echo "	[-c|--config ... ]		自定义配置文件，默认为abs-config"
	echo "					可包含需要远程执行的命令以及需要传送的文件"
	echo "					开头关键字要求为'com:::'或'file:::'"
	echo "	[-t|--sshtimeout ... ]		远程执行命令时的超时设置"
	echo "					默认为120s，单位为s，-1表示无超时"
	echo "	[-T|--fttimeout ... ]		传送文件时的超时设置"
	echo "					默认为120s，单位为s，-1表示无超时"
	echo "	[-L|--bwlimit ... ]		传送文件时的限速设置，单位为kbit/s"
	echo "					0表示无限速，默认为无限速"
	echo "	[-N|--noretry]			针对密码错主机的是否重试标志"
	echo "					使用本参数时表示无重试，以便版本向前兼容"
	echo "	[-o|--output ... ]		执行结果默认保存在当前目录的absresult文件中"
	echo "					可通过-o选项将执行结果保存在其他文件中"
	echo "	[-y|--yes ... ]			可设置对所有确认直接回答yes"
	echo "	[-p|--passwd] 			表示密码和SSH登录端口由用户输入"
	echo "	[-n|--ignore]			启用忽略，默认为不启用"
    	echo "  [-u|--user]            		user to ssh"
	echo "  [-i|--key]                      use rsa_key|dsa_key"
	echo ""
	echo "NOTICE:"
	echo "	-p|--passwd: all passwd and sshport must be input but not read from iplist"
	echo "	-n|--ignore: some ip will be ignored; otherwise-all ip will be handled"
	echo ""
}

prompt()
{
	while true
	do
		echo -e -n "$1 [yes/no/exit] ? "
		if [ "$CONFIRM_YES" == "1" ]; then
			echo "yes"
			echo ""
			return 0
		fi
		read PROMPT_ANSWER
		if [ -z "$PROMPT_ANSWER" ]; then
			continue
		else
			if [ "$PROMPT_ANSWER" == "yes" ]; then
				echo ""
				return 0
			elif [ "$PROMPT_ANSWER" == "no" ]; then
				echo ""
				return 1
			elif [ "$PROMPT_ANSWER" == "exit" ]; then
				echo ""
				exit 0
			else
				continue
			fi
		fi
	done
}

get_mypasswd()
{
	while true
	do
		echo -n "$1"
		stty -echo
		read MYPASSWD
		stty echo

		echo ""
		if [ -z "$MYPASSWD" ]; then
			continue
		fi

		echo ""
		prompt "========== 请确认您是否已输入了正确的密码..."

		if [ $? -eq 0 ]; then
			break
		fi
	done
}

get_mysshport()
{
	while true
	do
		echo -n "$1"
		read MYSSHPORT

		if [ -z "$MYSSHPORT" ]; then
			continue
		fi

		echo ""
		prompt "========== 请确认您是否已输入了正确的SSH登录端口..."

		if [ $? -eq 0 ]; then
			break
		fi
	done
}

# 参数默认值
USER=root	# 一般情况均使用root用户登陆，因此简单在此设定，以后需要可进行配置文件配置
myIFS=":::"	# 配置文件中的分隔符
TOOLDIR=`pwd`

IPLIST="abs-iplist"		# IP列表，格式为IP 密码 端口
CONFIG_FILE="abs-config"	# 命令列表和文件传送配置列表，关键字为com:::和file:::
IGNRFLAG="noignr"		# 如果置为ignr，则脚本会进行忽略条件的判断
SSHTIMEOUT=60			# 远程命令执行相关操作的超时设定，单位为秒
SCPTIMEOUT=60			# 文件传送相关操作的超时设定，单位为秒
BWLIMIT=0			# 文件传送的带宽限速，单位为kbit/s
ABSRESULT="absresult"		# 执行结果默认保存在当前目录下的absresult文件中，可通过-o选项保存到其他文件中
ALLOPTION="$*"
PASSWDERROR_NORETRY=0
CONFIRM_YES=0
USE_KEY="no"                    #default use passwd
os_check;

# 入口参数分析
TEMP=`getopt -o hvVyl:c:t:T:L:Nno:piu: --long help,version,yes,iplist:,config:,sshtimeout:,fttimeout:,bwlimit:,noretry,ignore,output:,passwd,key,user: -- "$@" 2>/dev/null`

if [ $? != 0 ] ; then
	echo "ABS_ERROR: wrong option!"
	echo ""
	show_usage
	exit 1
fi

# 会将符合getopt参数规则的参数摆在前面，其他摆在后面，并在最后面添加--
eval set -- "$TEMP"

while true ; do

	if [ -z "$1" ]; then
		break;
	fi

	case "$1" in
		-h|--help) show_usage; exit 0;;
		-v|-V|--version) show_version; exit 0;;
		-l|--iplist) IPLIST=$2; shift 2;;
		-c|--config) CONFIG_FILE=$2; shift 2;;
		-t|--sshtimeout) SSHTIMEOUT=$2; shift 2;;
		-T|--fttimeout) SCPTIMEOUT=$2; shift 2;;
		-L|--bwlimit) BWLIMIT=$2; shift 2;;
		-N|--noretry) PASSWDERROR_NORETRY=1; shift;;
		-y|--yes) CONFIRM_YES=1; shift;;
		-o|--output) ABSRESULT="$2"; shift 2;;
		-p|--passwd) PASSWDINPUTFLAG=1; shift;;
		-n|--ignore) IGNRFLAG="ignr"; shift;;
        	-i|--key)   USE_KEY="yes"; shift;;
        	-u|--user)   USER=$2; shift 2;;
		--) shift;; 
		*) echo "ABS_ERROR: wrong option!"; echo ""; show_usage; exit 1 ;;
	esac
done



##########################################    main    ##########################################

if [ ! -f $IPLIST ]; then
	echo "ABS_ERROR: iplist \"$IPLIST\" not exists, please check!"
	echo ""
	exit 1
fi

if [ ! -f $CONFIG_FILE ]; then
	echo "ABS_ERROR: config \"$CONFIG_FILE\" not exists, please check!"
	echo ""
	exit 1
fi

cat $IPLIST | grep -v '^$' > $IPLIST.1
mv $IPLIST.1 $IPLIST


# 强制手工确认
#echo ""
#echo "========== 当前运行参数如下："
#echo "	\"$CONFIG_FILE\"    ---- as your config"
#echo "	\"$IPLIST\"    ---- as your iplist"
#echo "	\"$SSHTIMEOUT\"    ---- as your ssh timeout"
#echo "	\"$SCPTIMEOUT\"    ---- as your scp timeout"
#echo "	\"$BWLIMIT\"    ---- as your bwlimit"
#echo "	\"$IGNRFLAG\"    ---- as your ignore flag"
#echo

#prompt "========== 请对上述运行参数进行确认..."
#if [ $? -ne 0 ]; then
#	exit 0
#fi

#if [ "$PASSWDINPUTFLAG" == "1" ]; then
#	get_mypasswd "========== 请输入本批待处理IP的root用户登录密码："
#	get_mysshport "========== 请输入本批待处理IP的SSH登录端口："
#fi

while true	# 无限重复执行，直到没有密码错误为止（使用-N参数时则不进行重试2013.01.30）
do

BEGINDATETIME=`date "+%D %T"`
BEGINDATETIME_short=`date "+%H%M"`

IPTOTAL=`cat $IPLIST | wc -l`

#echo "========== $CONFIG_FILE 配置文件内容如下："
#cat $CONFIG_FILE
#echo "==========================================="
#echo ""
#echo "========== $IPLIST 文件中包含IP个数为: $IPTOTAL"

echo ""
#while true
#do
#	prompt "========== $CONFIG_FILE 和 $IPLIST 的内容如上所述，请进行确认..."
#	if [ $? -eq 0 ]; then
#		break
#	fi
#done

ignore_init;

IPSEQ=0
while [ $IPSEQ -lt $IPTOTAL ]
do
	let IPSEQ=$IPSEQ+1

	if [ "$PASSWDINPUTFLAG" == "1" ]; then
		IPSEQ_TEMP=0
		while read IP OTHERCOLS
		do
			let IPSEQ_TEMP=$IPSEQ_TEMP+1
			if [ $IPSEQ_TEMP -ge $IPSEQ ]; then
				break
			fi
		done < $IPLIST

		PASSWD="$MYPASSWD"
		PORT="$MYSSHPORT"
	else
		IPSEQ_TEMP=0
		while read IP USER PASSWD PORT OTHERCOLS
		do
			let IPSEQ_TEMP=$IPSEQ_TEMP+1
			if [ $IPSEQ_TEMP -ge $IPSEQ ]; then
				break
			fi
		done < $IPLIST
	fi

	echo "--- --- --- --- --- --- --- --- --- --- --- ---   $IPSEQ / $IPTOTAL   --- --- --- --- --- --- --- --- --- --- --- ---"
	echo ""

	if [ -z "$PASSWD" -o -z "$PORT" ]; then
		echo "========== $IP 密码或SSH登录端口信息缺失！"
		get_mypasswd "========== 请输入该IP的root登录用户密码："
		PASSWD="$MYPASSWD"
		get_mysshport "========== 请输入该IP的SSH登录端口："
		PORT="$MYSSHPORT"
	fi

	export ABSIP="$IP"
	export ABSUSER="$USER"
	export ABSKEY="$USE_KEY"
	export ABSPASSWD="$PASSWD"
	export ABSPORT="$PORT"
	export ABSSSHTIMEOUT="$SSHTIMEOUT"
	export ABSSCPTIMEOUT="$SCPTIMEOUT"
	export ABSBWLIMIT="$BWLIMIT"
	export ABSOSVER="$OS_VER"

	if [ "$PASSWDINPUTFLAG" == "1" ]; then
		array_ip_list[$IPSEQ]="$IP"
	else
		array_ip_list[$IPSEQ]="$IP\t$USER\t$PASSWD\t$PORT"
	fi

	# 如果启用了忽略，则进入忽略流程
	if [ ${IGNRFLAG} == "ignr" ]; then

		ignored_flag=0

		ii=0
		while [ $ii -lt $arry_ignore_pwd_length ]
		do
			if [ "${PASSWD}x" == "${arry_ignore_pwd[$ii]}x" ]; then
				ignored_flag=1
				break
			fi

			let ii=$ii+1
		done

		if [ $ignored_flag -eq 1 ]; then
			continue
		fi

		jj=0
		while [ $jj -lt $arry_ignore_ip_length ]
		do
			if [ ${IP}x == ${arry_ignore_ip[$jj]}x ]; then
				ignored_flag=1
				break
			fi

			let jj=$jj+1
		done

		if [ $ignored_flag -eq 1 ]; then
			array_ip_result[$IPSEQ]="IGNRED"
			continue
		fi

	fi

	# 针对一个$IP，执行配置文件中的一整套操作

	array_ip_result[$IPSEQ]="SUCCESS"

	while read eachline
	do
		# 空行或全部由空格、制表符所组成的行被忽略
		if [ -z "`echo $eachline | grep -v ^$`" ]; then
			continue
		fi

		# 行首第一个非空字符为#时，此行被认定为注释，不进行任何处理
		commentflag=${eachline:0:1}
		if [ "${commentflag}"x == "#"x ]; then
			continue
		fi

		myKEYWORD=`echo $eachline | awk -F"$myIFS" ' { print $1; } '`
		myCONFIGLINE="`echo $eachline | awk -F"$myIFS" ' { print $2; } '`"

		# 对配置文件中的预定义的可扩展特殊字符串进行扩展
		# 关键字#IP#，用$IP进行替换
		if [ ! -z "`echo "$myCONFIGLINE" | grep '#IP#'`" ]; then
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#IP#/$IP/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		# 时间相关关键字，用当前时间进行替换
		if [ ! -z "`echo "$myCONFIGLINE" | grep '#YYYY#'`" ]; then
			myYEAR=`date +%Y`
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#YYYY#/$myYEAR/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		if [ ! -z "`echo "$myCONFIGLINE" | grep '#MM#'`" ]; then
			myMONTH=`date +%m`
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#MM#/$myMONTH/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		if [ ! -z "`echo "$myCONFIGLINE" | grep '#DD#'`" ]; then
			myDATE=`date +%d`
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#DD#/$myDATE/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		if [ ! -z "`echo "$myCONFIGLINE" | grep '#hh#'`" ]; then
			myHOUR=`date +%H`
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#hh#/$myHOUR/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		if [ ! -z "`echo "$myCONFIGLINE" | grep '#mm#'`" ]; then
			myMINUTE=`date +%M`
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#mm#/$myMINUTE/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		if [ ! -z "`echo "$myCONFIGLINE" | grep '#ss#'`" ]; then
			mySECOND=`date +%S`
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#ss#/$mySECOND/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		# IPSEQ关键字，用当前IP的序列号替换，从1开始
		if [ ! -z "`echo "$myCONFIGLINE" | grep '#IPSEQ#'`" ]; then
			myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#IPSEQ#/$IPSEQ/g"`
			myCONFIGLINE=$myCONFIGLINE_temp
		fi

		# #1#..#6#关键字，用除了IP、密码、端口之后的列号替换，从1开始，最多到6
		if [ ! -z "`echo "$myCONFIGLINE" | grep -E '#[1..6]#'`" ]; then

			if [ ! -z "`echo "$myCONFIGLINE" | grep '#1#'`" ]; then
				thisCOLUMN1=`echo $OTHERCOLS | awk '{ print $1 }'`
				myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#1#/$thisCOLUMN1/g"`
				myCONFIGLINE=$myCONFIGLINE_temp
			fi

			if [ ! -z "`echo "$myCONFIGLINE" | grep '#2#'`" ]; then
				thisCOLUMN2=`echo $OTHERCOLS | awk '{ print $2 }'`
				myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#2#/$thisCOLUMN2/g"`
				myCONFIGLINE=$myCONFIGLINE_temp
			fi

			if [ ! -z "`echo "$myCONFIGLINE" | grep '#3#'`" ]; then
				thisCOLUMN3=`echo $OTHERCOLS | awk '{ print $3 }'`
				myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#3#/$thisCOLUMN3/g"`
				myCONFIGLINE=$myCONFIGLINE_temp
			fi

			if [ ! -z "`echo "$myCONFIGLINE" | grep '#4#'`" ]; then
				thisCOLUMN4=`echo $OTHERCOLS | awk '{ print $4 }'`
				myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#4#/$thisCOLUMN4/g"`
				myCONFIGLINE=$myCONFIGLINE_temp
			fi

			if [ ! -z "`echo "$myCONFIGLINE" | grep '#5#'`" ]; then
				thisCOLUMN5=`echo $OTHERCOLS | awk '{ print $5 }'`
				myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#5#/$thisCOLUMN5/g"`
				myCONFIGLINE=$myCONFIGLINE_temp
			fi

			if [ ! -z "`echo "$myCONFIGLINE" | grep '#6#'`" ]; then
				thisCOLUMN6=`echo $OTHERCOLS | awk '{ print $6 }'`
				myCONFIGLINE_temp=`echo $myCONFIGLINE | sed "s/#6#/$thisCOLUMN6/g"`
				myCONFIGLINE=$myCONFIGLINE_temp
			fi

		fi

		# 配置文件中有关键字com:::，就调用ssh.exp进行远程命令执行
		if [ "$myKEYWORD"x == "com"x ]; then

			$TOOLDIR/ssh.exp "${myCONFIGLINE}"
			SSHRESULT=$?
			if [ $SSHRESULT -eq 2 ]; then
				array_ip_result[$IPSEQ]="FAILED_CONNECT"
				break;
			elif [ $SSHRESULT -eq 3 ]; then
				array_ip_result[$IPSEQ]="FAILED_PASSWD"
				break;
			fi

		# 配置文件中有关键字file:::，就调用scp.exp进行文件传送
		elif [ "$myKEYWORD"x == "file"x ]; then
			SOURCEFILE="`echo $myCONFIGLINE | awk ' { print $1; } '`"
			DESTDIR=`echo $myCONFIGLINE | awk ' { print $2; } ' `
			DIRECTION=`echo $myCONFIGLINE | awk ' { print $3; } ' `
			$TOOLDIR/scp.exp "$SOURCEFILE" "$DESTDIR" "$DIRECTION"
			SCPRESULT=$?
			if [ $SCPRESULT -eq 2 ]; then
				array_ip_result[$IPSEQ]="FAILED_CONNECT"
				break;
			elif [ $SCPRESULT -eq 3 ]; then
				array_ip_result[$IPSEQ]="FAILED_PASSWD"
				break;
			elif [ $SCPRESULT -eq 4 ]; then
				array_ip_result[$IPSEQ]="FAILED_FILE"
				break;
			fi

		else
			echo "ABS_ERROR: configuration wrong! [$eachline] "
			echo "           where KEYWORD should not be [$myKEYWORD], but 'com' or 'file'"
			echo "           if you dont want to run it, you can comment it with '#'"
			echo ""
			exit
		fi

	done < $CONFIG_FILE

done


ENDDATETIME=`date "+%D %T"`


echo "=============================   运 行 情 况 小 结   ==============================="
echo "========== 本次运行时间：$BEGINDATETIME -- $ENDDATETIME"
echo "========== 本次运行命令语句：$0 $ALLOPTION"

if [ $IPSEQ -ne $IPTOTAL ]; then
	echo "the lastest IPSEQ is not equal length of $IPLIST, warning!!!"
	echo "IPSEQ=$IPSEQ"
	echo "length of $IPLIST=$IPTOTAL"
fi

TJ_SUCCESS=0
TJ_FAILED_CONNECT=0
TJ_FAILED_PASSWD=0
TJ_FAILED_FILE=0
TJ_IGNRED=0
rm -f ./$ABSRESULT
for mmm in `seq 1 $IPTOTAL`
do
	if [ "${array_ip_result[$mmm]}" == "SUCCESS" ]; then
		let TJ_SUCCESS=$TJ_SUCCESS+1
	elif [ "${array_ip_result[$mmm]}" == "FAILED_CONNECT" ]; then
		let TJ_FAILED_CONNECT=$TJ_FAILED_CONNECT+1
	elif [ "${array_ip_result[$mmm]}" == "FAILED_PASSWD" ]; then
		let TJ_FAILED_PASSWD=$TJ_FAILED_PASSWD+1
	elif [ "${array_ip_result[$mmm]}" == "FAILED_FILE" ]; then
		let TJ_FAILED_FILE=$TJ_FAILED_FILE+1
	elif [ "${array_ip_result[$mmm]}" == "IGNRED" ]; then
		let TJ_IGNRED=$TJ_IGNRED+1
	fi

	echo -e "${array_ip_list[$mmm]}\t${array_ip_result[$mmm]}" >> $ABSRESULT
done

echo "========== 本次共处理IP数: $IPTOTAL"
echo "========== 本次成功处理IP数: $TJ_SUCCESS"
echo "========== 本次因连接失败导致未处理的IP数: $TJ_FAILED_CONNECT"
echo "========== 本次因文件名或目录名错误导致未处理的IP数: $TJ_FAILED_FILE"
echo "========== 本次因密码错误导致未处理的IP数: $TJ_FAILED_PASSWD"
echo "========== 本次被忽略处理的IP数: $TJ_IGNRED"
echo "========== 更多详细信息请见$ABSRESULT"

if [ $TJ_FAILED_CONNECT -gt 0 ]; then
	echo "========== 连接失败IP列表："
	if [ $TJ_FAILED_CONNECT -gt 10 ]; then
		cat $ABSRESULT | grep FAILED_CONNECT | head -n10 
		echo "......"
	else
		cat $ABSRESULT | grep FAILED_CONNECT
	fi
fi

if [ $TJ_FAILED_FILE -gt 0 ]; then
	echo "========== 源文件名或目标地址错误的IP列表："
	if [ $TJ_FAILED_FILE -gt 10 ]; then
		cat $ABSRESULT | grep FAILED_FILE | head -n10 
		echo "......"
	else
		cat $ABSRESULT | grep FAILED_FILE
	fi
fi

if [ $TJ_FAILED_PASSWD -gt 0 ]; then
	echo "========== 密码错误IP列表："
	cat $ABSRESULT | grep FAILED_PASSWD
fi
echo "==================================================================================="
echo ""


if [ $TJ_FAILED_PASSWD -eq 0 ]; then
	break
else
	if [ $PASSWDERROR_NORETRY -eq 0 ]; then
		cp $IPLIST $IPLIST.$BEGINDATETIME_short
		cp $ABSRESULT $ABSRESULT.$BEGINDATETIME_short

		get_mypasswd "========== 针对上述密码错误的IP，请提供正确的密码之一，以便再次执行: "

		rm -f $IPLIST
		for mmm in `seq 1 $IPTOTAL`
		do
			if [ "${array_ip_result[$mmm]}" == "FAILED_PASSWD" ]; then
				IP=`echo -e "${array_ip_list[$mmm]}" | awk '{ print $1 }'`

				if [ "$PASSWDINPUTFLAG" == "1" ]; then
					echo -e "$IP" >> $IPLIST
				else
					PORT=`echo -e "${array_ip_list[$mmm]}" | awk '{ print $3 }'`
					echo -e "$IP\t$MYPASSWD\t$PORT" >> $IPLIST
				fi
			fi
		done
	else
		break
	fi
fi

done

exit 0

